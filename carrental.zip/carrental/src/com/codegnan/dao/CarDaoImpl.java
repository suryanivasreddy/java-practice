package com.codegnan.dao;

import java.util.ArrayList;
import java.util.List;

import com.codegnan.carrentalmodel.Car;
import com.codegnan.exceptions.CarNotFoundException;

public class CarDaoImpl implements CarDao {
List<Car>carList=new ArrayList<>();
	@Override
	public void save(Car car) {
		// TODO Auto-generated method stub
		carList.add(car);
		System.out.println(carList);
	}

	@Override
	public List<Car> findAll() {
		 
		return carList;
	}

	@Override
	public Car findById(int id) throws CarNotFoundException {
		for(Car e:carList) {
			 if(e.getId()==id) {
				 return e;
			 }
			 
		 }
		 throw new CarNotFoundException("Car with Id : "+id+" Not Found");
		
	}

	@Override
	public Car update(Car car) throws CarNotFoundException {
		for (int i=0;i<carList.size();i++) {
			if(carList.get(i).getId()==car.getId()) {
				carList.set(i, car);
				return car;
			}
		}
		throw new CarNotFoundException("Car with Id "+ car.getId()+" Not Found cannot update");
		
	}

	@Override
	public void deleteById(int id) throws CarNotFoundException {
		 boolean found=false;
		 for(int i=0;i<carList.size();i++) {
			 if(carList.get(i).getId()==id) {
				 carList.remove(i);
				 found=true;
				 break;
			 }
		 }
		 if(!found) {
			 throw new CarNotFoundException("car with id "+id+" not found cannot delete");
		 }
		
	}

	

}
