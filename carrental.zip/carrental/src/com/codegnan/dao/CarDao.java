package com.codegnan.dao;

import java.util.List;

import com.codegnan.carrentalmodel.Car;
import com.codegnan.exceptions.CarNotFoundException;

public interface CarDao {
	public void save(Car car);
	public List<Car> findAll();
	public Car findById(int id)throws CarNotFoundException;
	public Car update(Car car)throws CarNotFoundException;
	public void deleteById(int id)throws CarNotFoundException;
	

}
