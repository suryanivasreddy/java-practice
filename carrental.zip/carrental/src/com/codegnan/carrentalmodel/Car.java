package com.codegnan.carrentalmodel;

public class Car {
private int id;
private String carModel;
private double price;
private boolean availability;
public Car() {
	super();
	// TODO Auto-generated constructor stub
}
public Car(int id, String carModel, double price, boolean availability) {
	super();
	this.id = id;
	this.carModel = carModel;
	this.price = price;
	this.availability = availability;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getCarModel() {
	return carModel;
}
public void setCarModel(String carModel) {
	this.carModel = carModel;
}
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}
public boolean isAvailability() {
	return availability;
}
public void setAvailability(boolean availability) {
	this.availability = availability;
}
@Override
public String toString() {
	return "Car [id=" + id + ", carModel=" + carModel + ", price=" + price + ", availability=" + availability + "]";
}

}
