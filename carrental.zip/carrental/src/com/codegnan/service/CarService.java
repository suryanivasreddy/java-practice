package com.codegnan.service;

import java.util.List;

import com.codegnan.carrentalmodel.Car;
import com.codegnan.exceptions.CarNotFoundException;

public interface CarService {
public void addCar(Car car);
public List<Car>getAllCar();
public Car getCarById(int id)throws CarNotFoundException;
public Car updateCar(Car car)throws CarNotFoundException;
public void deleteCar(int id)throws CarNotFoundException;
}
