package com.codegnan.service;

import java.util.List;

import com.codegnan.carrentalmodel.Car;
import com.codegnan.dao.CarDao;
import com.codegnan.dao.CarDaoImpl;
import com.codegnan.exceptions.CarNotFoundException;

public class CarServiceImpl implements CarService {
CarDao dao=new CarDaoImpl();
	@Override
	public void addCar(Car car) {
		 dao.save(car);
	}

	@Override
	public List<Car> getAllCar() {
		
		return dao.findAll();
	}

	@Override
	public Car getCarById(int id) throws CarNotFoundException {
		// TODO Auto-generated method stub
		return dao.findById(id);
	}

	@Override
	public Car updateCar(Car car) throws CarNotFoundException {
		
		return dao.update(car);
	}

	@Override
	public void deleteCar(int id) throws CarNotFoundException {
		 dao.deleteById(id);
		
	}

	
}
