package com.codegnan.controller;

import java.util.List;

import com.codegnan.carrentalmodel.Car;
import com.codegnan.exceptions.CarNotFoundException;
import com.codegnan.service.CarService;
import com.codegnan.service.CarServiceImpl;

public class CarController {

	public static void main(String[] args) {
		CarService service = new CarServiceImpl();

		service.addCar(new Car(1, "i20", 2000, true));
		service.addCar(new Car(2, "i10", 1600, true));
		service.addCar(new Car(3, "Thar", 2600, true));
		service.addCar(new Car(4, "xuv700", 2800, true));
		service.addCar(new Car(5, "Xl6", 2300, true));
		System.out.println("Car added successfully");
		System.out.println("All Cars");
		System.out.println("--------------------------------");
		List<Car> cars = service.getAllCar();
		for (Car c : cars) {
			System.out.println(c);
		}
		
		System.out.println("Fetching Car with ID:2 ");
		try {
			Car fetchCar=service.getCarById(2);
			System.out.println(fetchCar);
		} catch (CarNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("Update the Car with id 3");
		try {
			Car updated=service.updateCar(new Car(3,"thar",3000,true));
			System.out.println("Updated Car :"+ updated);
		} catch (CarNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		//deleteing
		try {
			service.deleteCar(1);
			System.out.println("car deleted successfully");
		} catch (CarNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("After all modification car list");
		List<Car> carz = service.getAllCar();
		for (Car c : carz) {
			System.out.println(c);
		}
		
	}

}
